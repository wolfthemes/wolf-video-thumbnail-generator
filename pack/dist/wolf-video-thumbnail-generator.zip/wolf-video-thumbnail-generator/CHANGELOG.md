#### 5th January 2018 - Version 1.0.5

* Other: Don't set the generated video thumbnail as featured image automatically

#### 22th November 2017 - Version 1.0.4

* Other: Enable generator in work, release and event posts

#### 17th November 2017 - Version 1.0.3

* Other: Enable generator in content block posts

#### 9th September 2017 - Version 1.0.2

* Other: Stop setting the generated thumbnail as featured image automatically

#### 3rd January 2017 - Version 1.0.1

* Tweak: Rename Wolf_Video_Thumbnail class to Wolf_Video_Thumbnail_Generator_Processor to avoid conflict with old plugin and theme versions

#### 16th December 2016 - Version 1.0.0

* Initial release