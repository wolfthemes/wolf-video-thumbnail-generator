#### 3rd January 2017 - Version 1.0.1

* Tweak: Rename Wolf_Video_Thumbnail class to Wolf_Video_Thumbnail_Generator_Processor to avoid conflict with old plugin and theme versions

#### 16th December 2016 - Version 1.0.0

* Initial release