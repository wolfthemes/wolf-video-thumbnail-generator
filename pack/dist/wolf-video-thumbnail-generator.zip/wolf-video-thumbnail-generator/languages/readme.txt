How to translate your theme or plugin:
https://wlfthm.es/translate

--------

Did you translate the plugin in another language or improved an existing translation?
Please help us improving the plugin by sending us the files!
contact@wolfthemes.com

Thank you