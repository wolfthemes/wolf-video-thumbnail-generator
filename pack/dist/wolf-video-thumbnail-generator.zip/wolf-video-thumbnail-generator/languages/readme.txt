How to translate your theme or plugin:
https://docs.wolfthemes.com/tutorial/translate-wordpress-theme/

--------

Did you translate the plugin in another language or improved an existing translation?
Please help us improving the plugin by sending us the files!
contact@wolfthemes.com

Thank you

