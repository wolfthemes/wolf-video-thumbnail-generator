<?php
/**
 * Wolf Video Thumbnail Generator Uninstall
 *
 * Uninstalling Wolf Video Thumbnail Generator
 *
 * @author WolfThemes
 * @category Core
 * @package WolfVideoThumbnailGenerator/Uninstaller
 * @version 1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}