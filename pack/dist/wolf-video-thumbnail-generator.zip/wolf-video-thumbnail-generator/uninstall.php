<?php
/**
 * Video Thumbnail Generator Uninstall
 *
 * Uninstalling Video Thumbnail Generator
 *
 * @author WolfThemes
 * @category Core
 * @package WolfVideoThumbnailGenerator/Uninstaller
 * @version 1.0.0
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
