<?php
/**
 * Wolf Recipes Uninstall
 *
 * Uninstalling Wolf Recipes
 *
 * @author WolfThemes
 * @category Core
 * @package WolfRecipes/Uninstaller
 * @version 1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}