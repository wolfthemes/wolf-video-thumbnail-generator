# Thanks for downloading Video Thumbnail Generator!

Generate an image from the first video in the post. Supports YouTube and Vimeo.

## Plugin page
https://github.com/wolfthemes/wolf-video-thumbnail-generator

## Support
Verified customers who have purchased a premium theme on [ThemeForest](http://wlfthm.es/tf)
will have access to support for this plugin in the [forums](http://wlfthm.es/help).

Have fun!
