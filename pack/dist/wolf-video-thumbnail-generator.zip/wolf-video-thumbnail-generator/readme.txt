Thanks for downloading Wolf Video Thumbnail Generator!

Generate an image from the first video in the post. Supports YouTube and Vimeo.

Plugin page:
http://wolfthemes.com/plugin/wolf-video-thumbnail-generator

Being a free product, this plugin is distributed as-is without official support.
Verified customers however, who have purchased a premium theme
at http://themeforest.net/user/Wolf-Themes/portfolio?ref=Wolf-Themes
will have access to support for this plugin in the forums
http://help.wolfthemes.com/

Have fun!